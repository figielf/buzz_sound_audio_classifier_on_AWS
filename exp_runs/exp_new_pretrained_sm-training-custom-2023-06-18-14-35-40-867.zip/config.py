DEFAULT_BUCKET = 'gdsc.data.public.us-east-1'
DEFAULT_REGION = 'us-east-1'
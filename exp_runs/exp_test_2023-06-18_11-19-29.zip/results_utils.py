import os
import datetime
import zipfile


RESULTS_FOLDER = '/root/data/experiments/exp_runs'


def archive_solution_files(folder_full_path):
    # zips only files within folder_full_path folder, not indludes subfolders
    
    current_folder = os.path.basename(folder_full_path)
    current_datetime = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    
    zip_filename = f'{current_folder}_{current_datetime}.zip'
    zip_file_full_path = os.path.join(RESULTS_FOLDER, zip_filename)

    files_to_archive = os.listdir(folder_full_path)
    with zipfile.ZipFile(zip_file_full_path, 'w') as zipf:
        for file_name in files_to_archive:
            if not file_name.endswith('.ipynb_checkpoints'):  # exclude .ipynb_checkpoints files
                file_path = os.path.join(folder_full_path, file_name)
                zipf.write(file_path, arcname=file_name)
    
    print(f'Saved solution files to {zip_file_full_path}')
